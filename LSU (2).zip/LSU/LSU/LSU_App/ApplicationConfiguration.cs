﻿namespace Sprint1.LSU_App
{
    internal class ApplicationConfiguration
    {
    }
}